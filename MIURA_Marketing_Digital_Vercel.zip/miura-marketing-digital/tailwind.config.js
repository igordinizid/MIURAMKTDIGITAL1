module.exports = { content: ['./public/**/*.html', './public/**/*.js'], theme: { extend: { colors: { graphite: '#121214', blood: '#990000', titanium: '#A8A8B3' } } }, plugins: [] };
