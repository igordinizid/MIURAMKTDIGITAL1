# MIURA Marketing Digital

Landing page responsiva em HTML, Tailwind CSS compilado e JavaScript puro. API Node.js para envio de leads na Vercel. Sem CDN de CSS, fontes externas ou rastreadores. Logo atual é um wordmark provisório, não a identidade oficial.

## Publicar na Vercel

1. Extraia este ZIP e envie o conteúdo da pasta `miura-marketing-digital` para um repositório GitHub.
2. Na Vercel, clique em **Add New → Project**, importe o repositório e selecione **Framework Preset: Other**.
3. A raiz do projeto deve conter `package.json` e `vercel.json`. Build: `npm run build`. Output Directory: `public`. Install: `npm install` (ou `npm ci`, com o lockfile incluído).
4. Em **Settings → Environment Variables**, configure `LEADS_WEBHOOK_URL` com o endpoint HTTPS que recebe os contatos. Opcionalmente, configure `LEADS_WEBHOOK_TOKEN` para autenticação Bearer.
5. Clique em Deploy. Ao alterar variáveis, faça novo deploy. Nenhuma chave deve ser colocada em `public/app.js`.

O webhook recebe JSON com `name`, `phone` (somente dígitos), `goal`, `income`, `siteUrl`, `consent`, `source` e `createdAt`. Deve retornar HTTP 2xx somente após aceitar o lead. É possível utilizar uma integração com CRM, Make ou n8n. Sem webhook, o formulário mostra indisponibilidade: não simula um contato recebido e não salva dados.

## Executar e modificar

Requer Node.js 22 ou superior e npm.

```sh
npm ci
npm run check
npm run build
npx vercel dev
```

`vercel dev` requer sua própria conta Vercel e habilita `/api/leads` localmente. Para visualizar somente o layout, abra `public/index.html` após o build; o formulário precisa da API e não funciona em `file://`.

- `public/index.html`: seções, textos e acessibilidade.
- `src/styles.css`: Tailwind e design visual; execute o build após alterar.
- `public/styles.css`: CSS compilado incluído para visualizar o layout.
- `public/app.js`: simulador, sliders, modal e formulário.
- `api/leads.js`: validação no servidor e entrega ao webhook.
- `public/assets/logo.svg`: logo provisória. Substitua pelo SVG oficial. Se usar PNG/WebP, atualize ambos os caminhos no HTML.
- `vercel.json`: build, diretório público e cabeçalhos de segurança.
- `.env.example`: variáveis necessárias, sem segredos.

## Antes de divulgar

A auditoria é uma simulação de 3 segundos: não consulta o domínio, não executa PageSpeed e não verifica SEO. Os indicadores Crítica/Invisível estão marcados como fictícios.

O cenário da calculadora usa investimento × ROAS 4. O faturamento informado serve para comparar a proporção, não é somado à receita de anúncios. Não calcula ROI líquido: custos, margem, impostos e atribuição não foram informados. “35%” é hipótese ilustrativa do briefing. Valores finais dos sliders são limites da simulação, mesmo quando exibidos com “+”.

O case Empresa X / R$ 2,4 milhões e o gráfico animado são fictícios. Substitua por um case comprovado antes de anunciar resultados da agência. Não há promessa de retorno garantido.

Insira a logo oficial, configure e teste a entrega no CRM e atualize o modal de privacidade com o canal de contato e a política de retenção reais da Miura. O formulário tem validação, honeypot, restrição de origem e timeout. Para campanhas de grande volume, configure proteção contra abuso/rate limiting no provedor ou webhook; o honeypot não substitui isso.

## Verificação desta entrega

- `npm run check`: sintaxe JavaScript do front-end e da API.
- `npm run build`: CSS Tailwind compilado com sucesso.
- API verificada com chamadas simuladas: método incorreto, dados inválidos, integração ausente, entrega bem-sucedida e falha do webhook.
- Esta entrega não foi publicada na Vercel e não teve validação visual em navegador nesta sessão.

## Referências oficiais

- Configuração da Vercel: https://vercel.com/docs/project-configuration
- Variáveis de ambiente: https://vercel.com/docs/environment-variables
- Deploy via CLI: https://vercel.com/docs/projects/deploy-from-cli
- Tailwind CSS v3: https://v3.tailwindcss.com/docs/installation

O design e os textos seguem o briefing fornecido por Igor; os números ilustrativos não são evidências de desempenho real.
