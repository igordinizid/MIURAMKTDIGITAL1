'use strict';
module.exports = async function handler(req,res) {
  res.setHeader('Cache-Control','no-store');
  if(req.method!=='POST'){res.setHeader('Allow','POST');return res.status(405).json({error:'Método não permitido.'});}
  if(!String(req.headers['content-type']||'').includes('application/json'))return res.status(415).json({error:'Formato inválido.'});
  const origin=req.headers.origin;
  if(origin){try{if(new URL(origin).host!==req.headers.host)return res.status(403).json({error:'Origem não permitida.'});}catch{return res.status(403).json({error:'Origem inválida.'});}}
  let body=req.body;
  try{if(typeof body==='string')body=JSON.parse(body);}catch{return res.status(400).json({error:'Dados inválidos.'});}
  if(!body||typeof body!=='object'||Array.isArray(body))return res.status(400).json({error:'Dados inválidos.'});
  if(JSON.stringify(body).length>8192)return res.status(413).json({error:'Solicitação muito grande.'});
  if(body.website)return res.status(400).json({error:'Solicitação inválida.'});
  const goals=['Aumentar as vendas','Gerar leads qualificados','Reduzir custo por cliente','Melhorar meu site','Escalar a operação'];
  const incomes=['Até R$ 10 mil','R$ 10 mil a R$ 50 mil','R$ 50 mil a R$ 100 mil','R$ 100 mil a R$ 500 mil','Acima de R$ 500 mil'];
  const name=typeof body.name==='string'?body.name.trim():'';
  const phone=typeof body.phone==='string'?body.phone.replace(/\D/g,''):'';
  if(name.length<2||name.length>100||!/^(?:55)?\d{10,11}$/.test(phone)||!goals.includes(body.goal)||!incomes.includes(body.income)||body.consent!==true)return res.status(400).json({error:'Confira os campos e a autorização de contato.'});
  let siteUrl='';
  if(body.siteUrl){try{const parsed=new URL(body.siteUrl);if(!['https:','http:'].includes(parsed.protocol)||body.siteUrl.length>2048)throw new Error();siteUrl=parsed.origin+parsed.pathname;}catch{return res.status(400).json({error:'URL inválida.'});}}
  const webhook=process.env.LEADS_WEBHOOK_URL;
  if(!webhook)return res.status(503).json({error:'O agendamento está temporariamente indisponível. Tente novamente mais tarde.'});
  try{
    const target=new URL(webhook);if(target.protocol!=='https:')throw new Error('HTTPS required');
    const headers={'Content-Type':'application/json'};if(process.env.LEADS_WEBHOOK_TOKEN)headers.Authorization=`Bearer ${process.env.LEADS_WEBHOOK_TOKEN}`;
    const response=await fetch(target,{method:'POST',headers,redirect:'error',signal:AbortSignal.timeout(8000),body:JSON.stringify({name,phone,goal:body.goal,income:body.income,siteUrl,consent:true,source:'miura-landing-page',createdAt:new Date().toISOString()})});
    if(!response.ok)throw new Error('Upstream error');
    return res.status(200).json({ok:true});
  }catch{return res.status(502).json({error:'Não foi possível concluir o envio. Tente novamente em instantes.'});}
};
